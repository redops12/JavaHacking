Everything you need to use BreezySwing and TerminalIO is in this zip file.
Installation instructions are given on our website.

BreezySwing.jar       The easiest way to use our packages is to install
TerminalIO.jar        these two jar files.

BreezySwing           These folders contain the class files. Only use these if
TerminalIO            you are not going to use the jar files. Each set of class
                      files is installed in its own folder on your computer.

BreezySwingDoc        These folders contain Java html-style documentation. Retain
  BreezySwing         the folder structure when you copy this material to your
  TerminalIO          computer. The top level page is index.html.

Swing Sources         This folder contains source code for all the classes.

Swing Tests           If you change the source code and would like to do some
                      regression tests, you will find the java programs in this
                      folder useful.

dependency cache      Use the files in this folder if you have trouble running
                      BreezySwing or TerminalIO in the JBuilder 3 or 4 
                      development environment.
                      
Happy programming :-)